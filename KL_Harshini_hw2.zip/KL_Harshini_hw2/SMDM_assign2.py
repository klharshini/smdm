# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 18:35:12 2019

@author: harshi
"""
#Author: Lakshmi Harshini Kuchibhotla, SU ID: 230997383, SU email: lkuchibh@syr.edu

#import statements: networkx is used to draw graph, mathplotlib.pyplot is used to plot/save the graph w.r.t axes
import twitter
import sys
import time
from urllib.error import URLError
from http.client import BadStatusLine
from functools import partial
from sys import maxsize as maxint
import networkx as nx
import matplotlib.pyplot as plt

#Initilized to 0, finally they give the total api calls made for each functionality
friendsFollowersRequestTotal = 0
profileRequestTotal = 0
MAX_NODES = 140

#Graph object used to do generate and manipulate graph
G=nx.Graph()

#Get consumer keys and token keys from the created app. Use these keys to make api calls
#Source: Cookbook, added all the necessary keys
def oauth_login():
    # XXX: Go to http://twitter.com/apps/new to create an app and get values
    # for these credentials that you'll need to provide in place of these
    # empty string values that are defined as placeholders.
    # See https://developer.twitter.com/en/docs/basics/authentication/overview/oauth
    # for more information on Twitter's OAuth implementation.
    
    CONSUMER_KEY = '4Su6GorAHYqY9Uhdk2SU5zuWe'
    CONSUMER_SECRET = 'ylgIAt0LdO5jUyp66YZyNaVVi53QdLwjMasC4mUczqE64xjzRn'
    OAUTH_TOKEN = '928095374471962624-rTHLND3cvIrGp3DLuHxTz6mw39HCSOU'
    OAUTH_TOKEN_SECRET = '8275mQKIar8ZMBJ725MnUtcHkQPJbjvD8TCLXlHFYTS9b'
    
    auth = twitter.oauth.OAuth(OAUTH_TOKEN, OAUTH_TOKEN_SECRET,
                               CONSUMER_KEY, CONSUMER_SECRET)
    
    twitter_api = twitter.Twitter(auth=auth)
    return twitter_api

#Source: Cookbook, slides
#This makes the program to sleep when the rate limit for api calls exceeds.
#It handles all the exceptions caused due to api calls
def make_twitter_request(twitter_api_func, max_errors=10, *args, **kw): 
    
    # A nested helper function that handles common HTTPErrors. Return an updated
    # value for wait_period if the problem is a 500 level error. Block until the
    # rate limit is reset if it's a rate limiting issue (429 error). Returns None
    # for 401 and 404 errors, which requires special handling by the caller.
    
    def handle_twitter_http_error(e, wait_period=2, sleep_when_rate_limited=True):
    
        if wait_period > 3600: # Seconds
            print('Too many retries. Quitting.', file=sys.stderr)
            raise e
    
        # See https://dev.twitter.com/docs/error-codes-responses for common codes
    
        if e.e.code == 401:
            print ('Encountered 401 Error (Not Authorized)', file=sys.stderr)
            return None
        elif e.e.code == 404:
            print ('Encountered 404 Error (Not Found)', file=sys.stderr)
            return None
        elif e.e.code == 429: 
            print ('Encountered 429 Error (Rate Limit Exceeded)', file=sys.stderr)
            if sleep_when_rate_limited:
                print ( "Retrying in 15 minutes...ZzZ...", file=sys.stderr)
                sys.stderr.flush()
                time.sleep(60*15 + 5)
                print ( '...ZzZ...Awake now and trying again.', file=sys.stderr)
                return 2
            else:
                raise e # Caller must handle the rate limiting issue
        elif e.e.code in (500, 502, 503, 504):
            print('Encountered {0} Error. Retrying in {1} seconds' .format(e.e.code, wait_period), file=sys.stderr)
            time.sleep(wait_period)
            wait_period *= 1.5
            return wait_period
        else:
            raise e

    # End of nested helper function
    
    wait_period = 2 
    error_count = 0 

    while True:
        try:
            return twitter_api_func(*args, **kw)
        except twitter.api.TwitterHTTPError as e:
            error_count = 0 
            wait_period = handle_twitter_http_error(e, wait_period)
            if wait_period is None:
                return
        except URLError as e:
            error_count += 1
            print("URLError encountered. Continuing.", file=sys.stderr)
            if error_count > max_errors:
                print("Too many consecutive errors...bailing out.", file=sys.stderr)
                raise
        except BadStatusLine as e:
            error_count += 1
            print("BadStatusLine encountered. Continuing.", file=sys.stderr)
            if error_count > max_errors:
                print ("Too many consecutive errors...bailing out.", file=sys.stderr)
                raise

#Retrives the user profile for the requested id. Used to get info like followers_count, friends_count, screen_name etc
#Source: Cookbook, slides
def get_user_profile(twitter_api, screen_names=None, user_ids=None):
    global profileRequestTotal
    # Must have either screen_name or user_id (logical xor)
    assert (screen_names != None) != (user_ids != None),     "Must have screen_names or user_ids, but not both"
    
    items_to_info = {}

    items = screen_names or user_ids
    
    while len(items) > 0:

        # Process 100 items at a time per the API specifications for /users/lookup.
        # See http://bit.ly/2Gcjfzr for details.
        
        items_str = ','.join([str(item) for item in items[:100]])
        items = items[100:]

        if screen_names:
            response = make_twitter_request(twitter_api.users.lookup, screen_name=items_str) 
        else: # user_ids
            response = make_twitter_request(twitter_api.users.lookup, user_id=items_str) 
    
        for user_info in response:
            if screen_names:
                items_to_info[user_info['screen_name']] = user_info
            else: # user_ids
                items_to_info[user_info['id']] = user_info
    
    profileRequestTotal +=1
    return items_to_info

#Function takes the screen_name or user_id and returns the friend ids and follower ids for the requested user.
#Source: Cookbook, slides
def get_friends_followers_ids(twitter_api, screen_name=None, user_id=None,
                              friends_limit=maxint, followers_limit=maxint):
    global friendsFollowersRequestTotal
    # Must have either screen_name or user_id (logical xor)
    assert (screen_name != None) != (user_id != None), \
    "Must have screen_name or user_id, but not both"
    
    # See https://dev.twitter.com/docs/api/1.1/get/friends/ids and
    # https://dev.twitter.com/docs/api/1.1/get/followers/ids for details
    # on API parameters
    
    get_friends_ids = partial(make_twitter_request, twitter_api.friends.ids, 
                              count = 5000)
    get_followers_ids = partial(make_twitter_request, twitter_api.followers.ids, 
                                count = 5000)

    friends_ids, followers_ids = [], []
    
    for twitter_api_func, limit, ids, label in [
                    [get_friends_ids, friends_limit, friends_ids, "friends"], 
                    [get_followers_ids, followers_limit, followers_ids, "followers"]
                ]:
        
        if limit == 0: continue
        
        cursor = -1
        while cursor != 0:
        
            # Use make_twitter_request via the partially bound callable...
            if screen_name: 
                response = twitter_api_func(screen_name=screen_name, cursor=cursor)
            else: # user_id
                response = twitter_api_func(user_id=user_id, cursor=cursor)

            if response is not None:
                ids += response['ids']
                cursor = response['next_cursor']
                       
            if len(ids) >= limit or response is None:
                break

    friendsFollowersRequestTotal +=1         
    return friends_ids[:friends_limit], followers_ids[:followers_limit] 
                
#Function used to retrieve the reciprocal friends.
#reciprocal friends = common ids between the friend ids and follower ids retrieved from the get_friends_followers_ids
def get_reciprocal_friends(twitter_api, screen_name=None, user_id=None):
    friends_ids, followers_ids = get_friends_followers_ids(twitter_api, screen_name=screen_name, user_id = user_id, 
                                                           friends_limit=5000, followers_limit=5000)

    reciprocal_friends = list(set(friends_ids) & set(followers_ids))
    list_followers_count = []
    profiles={}
    
    #Sort the reciprocal friends using their followers_count
    for i in reciprocal_friends:
        profiles[i] = get_user_profile(twitter_api, user_ids = [i])[i]
        list_followers_count.append(profiles[i]['followers_count'])
    res = sorted(list_followers_count, reverse = True)
    dict_friends_count = {profiles[i]['followers_count']:i for i in reciprocal_friends}
    list_res = []
    
    #Get the top 5 reciprocal friends with highest followers count.
    #If reciprocal friends <=5, returns all the retrieved reciprocal friends
    if len(res)<6:
        list_res = reciprocal_friends
    else:
        for i in range(5):
            list_res.append(dict_friends_count[res[i]])
    #Top 5 friends found by using their followers count
    return list_res

#Copy Network size, diameter & average distance to a output file.
#If ids_empty is True, it means that there are no reciprocal friends and hence it doesnot create any graph
def print_to_File(ids_empty = False, screen_name = None, edges=0, nodes=0, totaldiameter=0, avgdistance=0):

    myfile = open("outputFile.txt", "w")
    
    if(ids_empty == True):
        myfile.write("There are no reciprocal friends for the requested Id: " + screen_name)
        myfile.write("\n\nHence, Social Network Graph is not created")
        
    else:
        myfile.write("This file stores the calculated network size, diameter and avg distance of the Social Network Graph")
        myfile.write("\n\nNetwork size is represented as a number of nodes and edges")
        myfile.write("\nNumber of edges: " + str(edges))
        myfile.write("\nNumber of nodes: " + str(nodes))
        myfile.write("\n\nDiameter: " + str(totaldiameter))
        myfile.write("\nAverage Distance: " + str(avgdistance))
        myfile.write("\n\nSocial Network Graph is generated as an image file in the current directory with filename as Network_Graph")
                
    myfile.close()

#This is a crawler function, it takes the screen_name and recursively using whileloop \
#generates the recripocal friends until ids count = MAX_NODES
#This function is also responsible to generate the Social Netwrok Graph by adding 
#the nodes and edges generated from the reciprocal friend_ids.
def crawler_friends_followers(twitter_api, screen_name=None, user_id=None):
    
    top_friends = get_reciprocal_friends(twitter_api,screen_name=screen_name, user_id=user_id)
    
    #adds the source node and its corresponding reciprocal friends with its edges   
    gList = [(screen_name,y) for y in top_friends]
    G.add_edges_from(gList)
    
    ids = next_queue = top_friends
    
    if (len(ids) == 0):
        print("\nThere are no reciprocal friends for",screen_name)
        print("\nHence exiting! No graph is created")
        print_to_File(ids_empty = True, screen_name = screen_name)
        return ids
    
    while len(ids)<MAX_NODES:
                
        print("nxtQ : ",next_queue)
        queue = next_queue.copy()
        next_queue = []
        for each in queue:
            if(len(ids)>=MAX_NODES):
                break
            print("entered id:",each)
            response = get_reciprocal_friends(twitter_api, user_id = each)
            
            #adds the distance-1, distance-2 and so on nodes and their corresponding edges
            gList = [(each,y) for y in response]
            G.add_edges_from(gList)
            next_queue += response
            ids += response
            
            #Displays the Updated count, Friends_followers api requests and user profile api requests
            print("Updated count ", len(ids))
            print("FF Reqs :" , friendsFollowersRequestTotal)
            print("Profile Reqs: ", profileRequestTotal)
                        
    print("\nThe generated",len(ids),"ids are: ")
    print(ids)
    
    #assigns a different color to each level of nodes: distance-1, distance-2 and so on nodes
    color_map = []
    for node in G:
        if (node == screen_name):
            color_map.append('blue')
        elif nx.shortest_path_length(G, screen_name, node) ==1:
            color_map.append('red')
        elif nx.shortest_path_length(G, screen_name, node) ==2:
            color_map.append('purple')
        elif nx.shortest_path_length(G, screen_name, node) ==3:
            color_map.append('orange')
        elif nx.shortest_path_length(G, screen_name, node) ==4:
           color_map.append('skyblue')
        elif nx.shortest_path_length(G, screen_name, node) ==5:
            color_map.append('pink')
        else: 
            color_map.append('yellow')  
    
    #plots the graph in the specified size        
    plt.figure(10,figsize=(25,25))     

    #Function used to draw the the graph with all the edges and nodes  
    nx.draw(G, with_labels=True, font_weight='bold', node_shape = 'h', node_color= color_map, 
            edge_color = 'red', node_size = 800, font_size = 13, width = 1, linewidths = 30) 
    
    #saves the graph to the local current directory as an image file
    plt.savefig("Network_Graph.png")
    
    #Calculates Network size, diameter and average distance
    edges_count = G.number_of_edges()
    nodes_count = G.number_of_nodes()
    diameter = nx.diameter(G)
    average_distance = nx.average_shortest_path_length(G)
    print("Number of edges: ", edges_count) 
    print("Number of nodes: ", nodes_count)
    print("Diameter: ", diameter) 
    print("Average Distance: ", average_distance)
    
    #function call to print the output to a file
    print_to_File(edges = edges_count, nodes = nodes_count, totaldiameter = diameter, avgdistance = average_distance)
    
    #write the graph object to a pickle 
    #stores the object so that we can load the graph object externally
    nx.write_gpickle(G, "test.gpickle")

#Function call to the authorization login    
twitter_api = oauth_login()

#Program execution starts here. This program generates the Social Network Graph for the given user.
crawler_friends_followers(twitter_api, screen_name="kurahariharan")
