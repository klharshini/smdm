#Author: Lakshmi Harshini Kuchibhotla, e-mail: lkuchibh@sur.edu, SUID: 230997383
#This class is used to calculate the areas for the geometric shapes
class Calculate_Area:

#This is an instantiation of the class. 
#When the class object is created in main, this function is directly executed.    
    def __init__(self):
        print("\nThis function is executed from Calculate_Area class\n")
    
#This function calculates the area of the triangle by taking the inputs from the user
#Inputs: base, height  
#Output: returns area of triangle
#Exception handling is done using try, except blocks
    def triangle(self):
        sides=[]
        try:
            print("Enter base and height:")
            for i in range(2):
                print("Enter Side:",i+1)
                a=int(input())
                sides.append(a)               
            side1,side2=sides[0],sides[1]
            result=(side1*side2)/2
            print("Area of triangle with given sides:",sides,"is",result) 
            return result
        except ValueError:
            print("Input needs to be an Integer")
        except:
            print("Unexpected exception")
        finally:
            print("*****----------------------------------------*****") 
            
#This function calculates the area of the circle by taking radius from the user
#Inputs: radius  
#Output: returns area of circle
#using try and except, all the intermediate exceptions are handled
    def circle(self):
        pi=22/7
        try:
            print("Enter the radius:")
            radius = int(input())    
            result = pi*radius*radius
            print("Area of circle with given radius:",result)
            return result
        except ValueError:
            print("Input needs to be an Integer")
        except:
            print("Unexpected exception")
        finally:
            print("*****----------------------------------------*****")
    
#This function calculates the area of the rectangle by taking the inputs from the user
#Inputs: length, breadth  
#Output: returns area of rectangle
#exceptions are caught using exception handling
    def rectangle(self):
        sides=[]
        try:
            print("Enter length and breadth:")
            for i in range(2):
                print("Enter Side:",i+1)
                a=int(input())
                sides.append(a)
            side1,side2=int(sides[0]),int(sides[1])
            result=side1*side2
            print("Area of rectangle with given sides:",sides,"is",result)
            return result
        except ValueError:
            print("Input needs to be an Integer")
        except:
            print("Unexpected exception")
        finally:
            print("*****----------------------------------------*****")
    
#This function calculates the area of the square by taking the input from the user
#Inputs: side  
#Output: returns area of square
    def square(self):
        try:
            print("Enter Side:")
            side=int(input())
            result=side*side
            print("Area of square with given sides:",result)
            return result
        except ValueError:
            print("Input needs to be an Integer")
        except:
            print("Unexpected exception")
        finally:
            print("*****----------------------------------------*****") 
    
#This class is used to to perform multiple operations like generating pythogorean triplets and cubes for numbers
class Operations:

#This is a class instantiation. 
#When the class object is created in main, this function is directly executed.     
    def __init__(self):
        print("\nThis function is executed from Operations class\n")

#This function generates the triplets which satisfies the pythogorean theorem using x^2+y^2=z^2
#This function also prints list and dictionaries using list comprehension & dictionary comprehension
#exceptions are handled using the try and except
    def triplet_generator(self):
        try:
            print("This function generates pythogorean triplets under given number")
            print("Enter a number: ")
            n = int(input())
            print("Pythogorean triplets under ",n)
            list_result = [(x,y,z) for x in range(1,n) for y in range(x,n) for z in range(y,n) if x*x + y*y == z*z]
            type_1 = type(list_result)
            print("Type of the output is: "+str(type_1)+" and the triplets are:\n",list_result)
            #Converts the list to Dictionary using dictionary comprehension
            dict_result = {i:str(n) for n,i in enumerate(list_result)}
            type_2 = type(dict_result)
            print("\nType of the output is: "+str(type_2)+" and the triplets are:\n",dict_result)
            #Reversing the key value pairs from the given dictionary
            dict_comp = {v:k for k,v in dict_result.items()}
            print("\nAfter reversing key-value pairs:\n",dict_comp)
            #to remove any key value pairs from the dictionary using keys
            print("\nDo you want to remove key-value pairs from the dictionary:")
            opinion = input("Enter Y/y for yes: ")
            
            if (opinion == 'Y' or opinion == 'y'):
                keys=[]
                print("How many key value pairs do you want to remove?")
                pairs_del = int(input())
                print("The dictionary keys are ",dict_comp.keys())
                for i in range(1,pairs_del+1):
                    print("Enter key",i," from the above to remove")
                    inp = input("Key: ")
                    keys.append(inp)
                remove = {i for i in keys}
                #It removes key value pairs from the dictionary when the condition is satisfied
                updated_dict = {key:dict_comp[key] for key in dict_comp.keys() - remove}
                print("\nAfter deleting key-value pairs:\n",updated_dict)
                return list_result,dict_result,dict_comp,updated_dict        
            
            else:                
                print("Thanks for your opinion")  
                return list_result,dict_result,dict_comp
            
        except ValueError:
            print("Input needs to be an Integer")
        except:
            print("Unexpected exception")
        finally:
            print("*****----------------------------------------*****")

#This function takes input from the user and generates cubes using list comprehension by evaluating the condition
#Inputs: number of integers, and the numbers
#Output: returns the list     
#uses try, except for exception handling
    def cubes_generator(self):
        try:
            numbers = []
            print("Enter the number of integers: ")
            number = int(input())
            print("Enter the integers: ")
            for i in range(1,number+1):
                print("Enter integer ",i,": ")
                n=int(input())
                numbers.append(n)
            print("Entered numbers: ",numbers)
            num_list = [x for x in numbers if x>5]
            print("Numbers greater than 5:",num_list)
            #list comprehension using condition and expression
            list_comp = [x*x*x for x in numbers if x>5]
            print("Cubes for the given numbers which are greater than 5:",list_comp)
            return list_comp
        except ValueError:
            print("Input needs to be an Integer") 
        except:
            print("Unexpected exception")
        finally:
            print("*****----------------------------------------*****")

#Main function, when this module is run as a script, here is the start of the execution  
#In this, objects for classes are created and methods are invoked using these objects
if __name__ == "__main__":
    
    try:
        dict1 = {"Triangle":1, "Circle":2, "Rectangle":3, "Square":4, "Pythogoren triplets":5, "Cubes":6}
        while True:
            print("\n1:Triangle, 2:Circle, 3:Rectangle, 4:Square, 5:Pythogoren triplets, 6:Cubes")
            print("Any other number to exit")
            choice = int(input("Enter your choice of operation: "))
            if (choice!=0 and choice < 5):
                obj1 = Calculate_Area()
                if choice == dict1["Triangle"]:          
                    obj1.triangle()
                if choice == dict1["Rectangle"]:          
                    obj1.rectangle()
                if choice == dict1["Circle"]:          
                    obj1.circle()
                if choice == dict1["Square"]:          
                    obj1.square()
            elif choice in [5,6]:
                obj2 = Operations()
                if choice == dict1["Pythogoren triplets"]:
                    obj2.triplet_generator()
                if choice == dict1["Cubes"]:
                    obj2.cubes_generator()
            if(choice>6 or choice == 0):
                break;
    except KeyboardInterrupt:
        print("Unexpected exception") 
    except:
        print("Input needs to be an Integer")
    finally:
        print("****Exiting the program****")
